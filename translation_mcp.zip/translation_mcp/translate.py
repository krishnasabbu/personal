import fitz
from io import BytesIO

def mock_translate(text: str, lang: str) -> str:
    return f"[{lang.upper()}] {text}"

def translate_pdf_bytes(pdf_bytes: bytes, target_lang: str = "fr") -> bytes:
    doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    for page in doc:
        text = page.get_text()
        translated_text = mock_translate(text, target_lang)
        page.insert_text((72, 72), translated_text, fontsize=12)
    output = BytesIO()
    doc.save(output)
    return output.getvalue()
