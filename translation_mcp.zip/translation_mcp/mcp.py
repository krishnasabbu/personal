import logging
from fastmcp import FastMCP
from translation_mcp.translate import translate_pdf_bytes

mcp = FastMCP("Translation MCP")

@mcp.tool()
def translate_pdf(pdf_bytes: bytes, target_lang: str = "fr") -> bytes:
    """Translate PDF bytes and return translated PDF bytes"""
    return translate_pdf_bytes(pdf_bytes, target_lang)

@mcp.resource("config://app-version")
def get_app_version() -> str:
    return "v1.0.0"

if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    mcp.run()
