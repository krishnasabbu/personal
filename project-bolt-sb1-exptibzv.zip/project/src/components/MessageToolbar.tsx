import React from 'react';
import { Copy, ThumbsUp, ThumbsDown, Edit3, Share, Download, Clock } from 'lucide-react';
import { Message } from '../types/chat';
import { toast } from 'react-toastify';

interface MessageToolbarProps {
  message: Message;
  onUpdate: (updates: Partial<Message>) => void;
  onShare: (message: Message) => void;
  onEdit: (messageId: string) => void;
}

export function MessageToolbar({ message, onUpdate, onShare, onEdit }: MessageToolbarProps) {
  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message.content);
      toast.success('Copied to clipboard!', {
        position: "top-center",
        autoClose: 2000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
      });
    } catch (error) {
      toast.error('Failed to copy message');
    }
  };

  const handleLike = () => {
    onUpdate({ 
      liked: !message.liked, 
      disliked: message.liked ? message.disliked : false 
    });
    toast.success(message.liked ? 'Like removed' : 'Message liked!', {
      position: "top-center",
      autoClose: 1500,
      hideProgressBar: true,
    });
  };

  const handleDislike = () => {
    onUpdate({ 
      disliked: !message.disliked, 
      liked: message.disliked ? message.liked : false 
    });
    toast.success(message.disliked ? 'Dislike removed' : 'Feedback recorded', {
      position: "top-center",
      autoClose: 1500,
      hideProgressBar: true,
    });
  };

  const handleDownload = () => {
    const blob = new Blob([message.content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `message-${message.id.slice(0, 8)}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success('Message downloaded!', {
      position: "top-center",
      autoClose: 2000,
      hideProgressBar: true,
    });
  };

  const formatTime = (date: Date) => {
    return new Date(date).toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  const toolbarButtons = [
    {
      icon: Copy,
      onClick: handleCopy,
      title: 'Copy',
      className: 'hover:text-slate-700 dark:hover:text-slate-300 hover:bg-slate-200/60 dark:hover:bg-slate-700/60'
    },
    {
      icon: ThumbsUp,
      onClick: handleLike,
      title: message.liked ? 'Remove like' : 'Good response',
      className: message.liked 
        ? 'text-emerald-600 dark:text-emerald-400 bg-emerald-100/60 dark:bg-emerald-900/30' 
        : 'hover:text-emerald-600 dark:hover:text-emerald-400 hover:bg-emerald-100/60 dark:hover:bg-emerald-900/30'
    },
    {
      icon: ThumbsDown,
      onClick: handleDislike,
      title: message.disliked ? 'Remove dislike' : 'Bad response',
      className: message.disliked 
        ? 'text-red-500 dark:text-red-400 bg-red-100/60 dark:bg-red-900/30' 
        : 'hover:text-red-500 dark:hover:text-red-400 hover:bg-red-100/60 dark:hover:bg-red-900/30'
    },
    {
      icon: Edit3,
      onClick: () => onEdit(message.id),
      title: 'Edit',
      className: 'hover:text-blue-600 dark:hover:text-blue-400 hover:bg-blue-100/60 dark:hover:bg-blue-900/30'
    },
    {
      icon: Share,
      onClick: () => onShare(message),
      title: 'Share',
      className: 'hover:text-purple-600 dark:hover:text-purple-400 hover:bg-purple-100/60 dark:hover:bg-purple-900/30'
    },
    {
      icon: Download,
      onClick: handleDownload,
      title: 'Download',
      className: 'hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-indigo-100/60 dark:hover:bg-indigo-900/30'
    }
  ];

  return (
    <div className="flex items-center gap-1">
      {toolbarButtons.map((button, index) => (
        <button
          key={index}
          onClick={button.onClick}
          className={`
            p-2 rounded-lg transition-all duration-200 ease-out
            text-slate-500 dark:text-slate-400 hover:scale-110 active:scale-95
            ${button.className}
          `}
          title={button.title}
        >
          <button.icon size={16} />
        </button>
      ))}
      
      <div className="flex items-center gap-1.5 ml-2 text-xs text-slate-400 dark:text-slate-500 border-l border-slate-300/50 dark:border-slate-600/50 pl-3">
        <Clock size={12} />
        <span>{formatTime(message.timestamp)}</span>
      </div>
    </div>
  );
}