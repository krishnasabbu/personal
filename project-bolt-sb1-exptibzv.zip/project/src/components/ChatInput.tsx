import React, { useState, useRef, useEffect } from 'react';
import { Send, Sparkles } from 'lucide-react';

interface ChatInputProps {
  onSendMessage: (message: string) => void;
  disabled?: boolean;
}

export function ChatInput({ onSendMessage, disabled = false }: ChatInputProps) {
  const [message, setMessage] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`;
    }
  }, [message]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim() && !disabled) {
      onSendMessage(message.trim());
      setMessage('');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  return (
    <div className="border-t border-slate-200/50 dark:border-slate-800/50 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl p-4">
      <form onSubmit={handleSubmit} className="flex gap-4 items-end max-w-4xl mx-auto">
        <div className="flex-1 relative">
          <div className={`
            relative rounded-2xl transition-all duration-300 ease-out border
            ${isFocused 
              ? 'border-emerald-500/50 shadow-lg shadow-emerald-500/10' 
              : 'border-slate-300/50 dark:border-slate-600/50 hover:border-slate-400/50 dark:hover:border-slate-500/50'
            }
          `}>
            <textarea
              ref={textareaRef}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={handleKeyDown}
              onFocus={() => setIsFocused(true)}
              onBlur={() => setIsFocused(false)}
              placeholder="Message ChatGPT..."
              disabled={disabled}
              className="
                w-full px-6 py-4 pr-14 rounded-2xl resize-none
                bg-white/90 dark:bg-slate-800/90 backdrop-blur-sm border-0 
                text-slate-800 dark:text-slate-200 placeholder-slate-500 dark:placeholder-slate-400
                focus:outline-none transition-all duration-200
                disabled:opacity-50 disabled:cursor-not-allowed
                min-h-[56px] max-h-[120px]
              "
              rows={1}
            />
            
            {/* Sparkles decoration when focused */}
            {isFocused && (
              <div className="absolute top-3 right-16 text-emerald-500 animate-pulse">
                <Sparkles size={16} />
              </div>
            )}
          </div>
        </div>
        
        <button
          type="submit"
          disabled={!message.trim() || disabled}
          className="
            p-4 rounded-2xl transition-all duration-300 ease-out
            bg-gradient-to-r from-emerald-500 to-emerald-600
            hover:from-emerald-600 hover:to-emerald-700
            disabled:from-slate-400 disabled:to-slate-500
            text-white shadow-lg hover:shadow-emerald-500/25
            disabled:cursor-not-allowed
            hover:scale-105 active:scale-95 disabled:hover:scale-100
            border border-emerald-400/20 disabled:border-slate-400/20
            min-w-[56px] h-14 flex items-center justify-center
          "
          title="Send message (Enter)"
        >
          <Send size={20} className={`transition-transform duration-200 ${!disabled && message.trim() ? 'translate-x-0.5' : ''}`} />
        </button>
      </form>
    </div>
  );
}