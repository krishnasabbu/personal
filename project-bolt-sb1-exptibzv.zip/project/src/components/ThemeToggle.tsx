import React from 'react';
import { Sun, Moon } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

export function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();

  return (
    <button
      onClick={toggleTheme}
      className="
        p-2.5 rounded-xl transition-all duration-200 hover:scale-105
        bg-white/80 hover:bg-white dark:bg-slate-800/80 dark:hover:bg-slate-800
        border border-slate-200/50 dark:border-slate-700/50
        text-slate-600 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200
        shadow-sm hover:shadow-md backdrop-blur-sm
      "
      title={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
    >
      {theme === 'light' ? <Moon size={18} /> : <Sun size={18} />}
    </button>
  );
}