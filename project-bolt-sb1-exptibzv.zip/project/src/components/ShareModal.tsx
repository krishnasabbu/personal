import React from 'react';
import { X, Copy, Twitter, Facebook, Link } from 'lucide-react';
import { Message, ShareModalData } from '../types/chat';
import { toast } from 'react-toastify';

interface ShareModalProps {
  shareModal: ShareModalData;
  onClose: () => void;
}

export function ShareModal({ shareModal, onClose }: ShareModalProps) {
  if (!shareModal.isOpen || !shareModal.message) return null;

  const message = shareModal.message;

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(message.content);
      toast.success('Message copied to clipboard!');
      onClose();
    } catch (error) {
      toast.error('Failed to copy message');
    }
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Chat Message',
          text: message.content
        });
        onClose();
      } catch (error) {
        // User cancelled or error occurred
      }
    } else {
      handleCopyLink();
    }
  };

  const shareOptions = [
    {
      icon: Copy,
      label: 'Copy to Clipboard',
      onClick: handleCopyLink,
      className: 'hover:bg-blue-500/10 hover:text-blue-400'
    },
    {
      icon: Link,
      label: 'Native Share',
      onClick: handleNativeShare,
      className: 'hover:bg-green-500/10 hover:text-green-400'
    }
  ];

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="
        bg-gradient-to-br from-white to-slate-50 dark:from-slate-800 dark:to-slate-700 
        border border-slate-200/50 dark:border-slate-600/50 rounded-2xl shadow-2xl
        w-full max-w-md p-6 animate-scale-in
      ">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-slate-800 dark:text-white">Share Message</h3>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-600/50 text-slate-400 hover:text-slate-600 dark:hover:text-white transition-all duration-200"
          >
            <X size={18} />
          </button>
        </div>

        {/* Message Preview */}
        <div className="bg-slate-100/50 dark:bg-slate-900/50 rounded-xl p-4 mb-6 border border-slate-200/30 dark:border-slate-600/30">
          <p className="text-slate-700 dark:text-slate-300 text-sm line-clamp-3">
            {message.content}
          </p>
        </div>

        {/* Share Options */}
        <div className="space-y-2">
          {shareOptions.map((option, index) => (
            <button
              key={index}
              onClick={option.onClick}
              className={`
                w-full flex items-center gap-3 p-3 rounded-xl
                bg-slate-100/30 dark:bg-slate-700/30 border border-slate-200/30 dark:border-slate-600/30
                text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white
                transition-all duration-200 hover:scale-[1.02]
                ${option.className}
              `}
            >
              <option.icon size={18} />
              <span className="font-medium">{option.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}