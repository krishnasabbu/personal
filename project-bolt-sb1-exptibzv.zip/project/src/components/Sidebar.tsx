import React from 'react';
import { Plus, Trash2, MessageSquare, X } from 'lucide-react';
import { ChatSession } from '../types/chat';

interface SidebarProps {
  sessions: ChatSession[];
  currentSessionId: string | null;
  onNewChat: () => void;
  onSelectSession: (sessionId: string) => void;
  onClearAll: () => void;
  isOpen: boolean;
  onClose: () => void;
}

export function Sidebar({ 
  sessions, 
  currentSessionId, 
  onNewChat, 
  onSelectSession, 
  onClearAll, 
  isOpen,
  onClose
}: SidebarProps) {
  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 lg:hidden"
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <div className={`
        fixed lg:relative top-0 left-0 h-full w-64 z-50
        bg-white dark:bg-slate-900 
        border-r border-slate-200/50 dark:border-slate-800/50
        transform transition-all duration-300 ease-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        flex flex-col
      `}>
        {/* Header */}
        <div className="p-4 border-b border-slate-200/50 dark:border-slate-800/50">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-slate-800 dark:text-white">
              ChatGPT
            </h2>
            <button
              onClick={onClose}
              className="lg:hidden p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-all duration-200"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* New Chat Button */}
        <div className="p-3">
          <button
            onClick={onNewChat}
            className="
              w-full flex items-center gap-3 px-4 py-3 rounded-xl
              bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 
              border border-slate-200/50 dark:border-slate-700/50
              text-slate-700 dark:text-slate-200 font-medium 
              transition-all duration-200 hover:scale-[1.02] active:scale-[0.98]
            "
            title="Start a new chat"
          >
            <Plus size={18} />
            <span className="text-sm">New chat</span>
          </button>
        </div>

        {/* Sessions List */}
        <div className="flex-1 overflow-y-auto px-2 custom-scrollbar">
          {sessions.length === 0 ? (
            <div className="text-center py-8 text-slate-400 dark:text-slate-500">
              <MessageSquare size={28} className="mx-auto mb-3 opacity-50" />
              <p className="text-sm">No conversations yet</p>
            </div>
          ) : (
            <div className="space-y-1">
              {sessions.map((session) => (
                <button
                  key={session.id}
                  onClick={() => onSelectSession(session.id)}
                  className={`
                    w-full text-left px-3 py-3 rounded-xl transition-all duration-200
                    hover:bg-slate-100 dark:hover:bg-slate-800 group
                    ${currentSessionId === session.id 
                      ? 'bg-slate-100 dark:bg-slate-800 border-l-2 border-emerald-500' 
                      : ''
                    }
                  `}
                  title={session.title}
                >
                  <div className="truncate text-sm font-medium text-slate-700 dark:text-slate-200 group-hover:text-slate-900 dark:group-hover:text-white transition-colors">
                    {session.title}
                  </div>
                  <div className="text-xs text-slate-500 dark:text-slate-400 mt-1 flex items-center gap-2">
                    <span>{session.messages.length} messages</span>
                    <span className="w-1 h-1 bg-slate-400 dark:bg-slate-500 rounded-full"></span>
                    <span>{new Date(session.updatedAt).toLocaleDateString()}</span>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Clear All Button */}
        {sessions.length > 0 && (
          <div className="p-3 border-t border-slate-200/50 dark:border-slate-800/50">
            <button
              onClick={onClearAll}
              className="
                w-full flex items-center gap-3 px-4 py-3 rounded-xl
                bg-red-50 hover:bg-red-100 dark:bg-red-900/20 dark:hover:bg-red-900/30 
                border border-red-200/50 dark:border-red-800/50
                text-red-600 dark:text-red-400 hover:text-red-700 dark:hover:text-red-300 font-medium
                transition-all duration-200 hover:scale-[1.02] active:scale-[0.98]
              "
              title="Clear all chat sessions"
            >
              <Trash2 size={16} />
              <span className="text-sm">Clear conversations</span>
            </button>
          </div>
        )}
      </div>
    </>
  );
}