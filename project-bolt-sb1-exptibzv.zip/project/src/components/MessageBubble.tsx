import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import { Message } from '../types/chat';
import { MessageToolbar } from './MessageToolbar';
import { User, Bot, Check, X } from 'lucide-react';

interface MessageBubbleProps {
  message: Message;
  onUpdate: (updates: Partial<Message>) => void;
  onShare: (message: Message) => void;
}

export function MessageBubble({ message, onUpdate, onShare }: MessageBubbleProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editContent, setEditContent] = useState(message.content);
  const isUser = message.role === 'user';

  const handleEdit = () => {
    setIsEditing(true);
    setEditContent(message.content);
  };

  const handleSaveEdit = () => {
    if (editContent.trim() !== message.content) {
      onUpdate({ content: editContent.trim() });
    }
    setIsEditing(false);
  };

  const handleCancelEdit = () => {
    setEditContent(message.content);
    setIsEditing(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSaveEdit();
    } else if (e.key === 'Escape') {
      handleCancelEdit();
    }
  };

  return (
    <div className={`
      group relative py-6 px-4 transition-all duration-300 ease-out
      ${isUser 
        ? 'bg-transparent' 
        : 'bg-slate-50/50 dark:bg-slate-800/30'
      }
      hover:bg-slate-50/70 dark:hover:bg-slate-800/40 
      border-b border-slate-100/50 dark:border-slate-800/30
    `}>
      <div className="max-w-4xl mx-auto">
        <div className="flex gap-4 items-start">
          {/* Avatar */}
          <div className={`
            flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center
            transition-all duration-300 ease-out group-hover:scale-110
            ${isUser 
              ? 'bg-gradient-to-br from-blue-500 to-blue-600 text-white shadow-lg shadow-blue-500/30' 
              : 'bg-gradient-to-br from-emerald-500 to-emerald-600 text-white shadow-lg shadow-emerald-500/30'
            }
          `}>
            {isUser ? <User size={16} /> : <Bot size={16} />}
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            {/* Role Label */}
            <div className="mb-2">
              <span className={`
                text-sm font-semibold tracking-wide
                ${isUser 
                  ? 'text-slate-800 dark:text-slate-200' 
                  : 'text-slate-700 dark:text-slate-300'
                }
              `}>
                {isUser ? 'You' : 'ChatGPT'}
              </span>
            </div>

            {/* Message Content */}
            {isEditing ? (
              <div className="space-y-4">
                <textarea
                  value={editContent}
                  onChange={(e) => setEditContent(e.target.value)}
                  onKeyDown={handleKeyDown}
                  className="
                    w-full p-4 rounded-xl resize-none border border-slate-300/50 dark:border-slate-600/50
                    bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm 
                    text-slate-800 dark:text-slate-200 placeholder-slate-500 dark:placeholder-slate-400
                    focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50
                    transition-all duration-200 shadow-sm
                  "
                  rows={4}
                  autoFocus
                />
                <div className="flex gap-3">
                  <button
                    onClick={handleSaveEdit}
                    className="
                      flex items-center gap-2 px-4 py-2 rounded-lg
                      bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700
                      text-white text-sm font-medium shadow-lg shadow-emerald-500/25
                      transition-all duration-200 hover:scale-105 active:scale-95
                    "
                  >
                    <Check size={14} />
                    Save
                  </button>
                  <button
                    onClick={handleCancelEdit}
                    className="
                      flex items-center gap-2 px-4 py-2 rounded-lg
                      bg-gradient-to-r from-slate-500 to-slate-600 hover:from-slate-600 hover:to-slate-700
                      text-white text-sm font-medium shadow-lg shadow-slate-500/25
                      transition-all duration-200 hover:scale-105 active:scale-95
                    "
                  >
                    <X size={14} />
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <div className="prose prose-slate dark:prose-invert max-w-none">
                <ReactMarkdown
                  components={{
                    p: ({ children }) => (
                      <p className="mb-4 last:mb-0 leading-relaxed text-slate-800 dark:text-slate-200 text-[15px]">
                        {children}
                      </p>
                    ),
                    code: ({ children, className }) => {
                      const isInline = !className;
                      return isInline ? (
                        <code className="
                          bg-slate-200/60 dark:bg-slate-700/60 px-2 py-1 rounded-md text-sm font-mono 
                          text-slate-800 dark:text-slate-200 border border-slate-300/30 dark:border-slate-600/30
                        ">
                          {children}
                        </code>
                      ) : (
                        <pre className="
                          bg-slate-900 dark:bg-slate-950 p-4 rounded-xl overflow-x-auto my-4
                          border border-slate-700/50 dark:border-slate-800/50 shadow-xl
                        ">
                          <code className="text-sm font-mono text-slate-100 dark:text-slate-200">
                            {children}
                          </code>
                        </pre>
                      );
                    },
                    ul: ({ children }) => (
                      <ul className="list-disc list-inside mb-4 space-y-2 text-slate-800 dark:text-slate-200">
                        {children}
                      </ul>
                    ),
                    ol: ({ children }) => (
                      <ol className="list-decimal list-inside mb-4 space-y-2 text-slate-800 dark:text-slate-200">
                        {children}
                      </ol>
                    ),
                    li: ({ children }) => (
                      <li className="leading-relaxed text-[15px]">{children}</li>
                    ),
                    blockquote: ({ children }) => (
                      <blockquote className="
                        border-l-4 border-blue-500/50 pl-4 italic my-4 
                        bg-blue-50/50 dark:bg-blue-900/20 py-3 rounded-r-lg 
                        text-slate-700 dark:text-slate-300
                      ">
                        {children}
                      </blockquote>
                    ),
                    h1: ({ children }) => (
                      <h1 className="text-2xl font-bold mb-4 text-slate-900 dark:text-slate-100">{children}</h1>
                    ),
                    h2: ({ children }) => (
                      <h2 className="text-xl font-bold mb-3 text-slate-900 dark:text-slate-100">{children}</h2>
                    ),
                    h3: ({ children }) => (
                      <h3 className="text-lg font-bold mb-3 text-slate-900 dark:text-slate-100">{children}</h3>
                    ),
                  }}
                >
                  {message.content}
                </ReactMarkdown>
              </div>
            )}

            {/* Message Toolbar */}
            {!isEditing && (
              <div className="mt-4 opacity-0 group-hover:opacity-100 transition-all duration-300">
                <MessageToolbar 
                  message={message} 
                  onUpdate={onUpdate} 
                  onShare={onShare}
                  onEdit={handleEdit}
                />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}