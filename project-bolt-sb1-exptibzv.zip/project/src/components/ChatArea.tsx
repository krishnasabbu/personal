import React, { useEffect, useRef, useState } from 'react';
import { RefreshCw, ArrowDown, Menu, Sparkles } from 'lucide-react';
import { ChatSession, Message, ShareModalData } from '../types/chat';
import { MessageBubble } from './MessageBubble';
import { ChatInput } from './ChatInput';
import { ShareModal } from './ShareModal';
import { ThemeToggle } from './ThemeToggle';
import { toast } from 'react-toastify';

interface ChatAreaProps {
  session: ChatSession | null;
  onSendMessage: (message: string) => void;
  onUpdateMessage: (messageId: string, updates: Partial<Message>) => void;
  onToggleSidebar: () => void;
}

export function ChatArea({ 
  session, 
  onSendMessage, 
  onUpdateMessage, 
  onToggleSidebar 
}: ChatAreaProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const [showScrollButton, setShowScrollButton] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [shareModal, setShareModal] = useState<ShareModalData>({ isOpen: false });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleScroll = () => {
    if (messagesContainerRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = messagesContainerRef.current;
      const isNearBottom = scrollHeight - scrollTop - clientHeight < 100;
      setShowScrollButton(!isNearBottom);
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [session?.messages]);

  const handleSendMessage = async (message: string) => {
    onSendMessage(message);
    setIsGenerating(true);
    
    // Simulate AI response with more realistic delay
    setTimeout(() => {
      const responses = [
        "I understand your question. Let me provide you with a comprehensive answer that covers all the important aspects you've mentioned.\n\nThis is a complex topic that requires careful consideration of multiple factors. Here are the key points to consider:\n\n1. **First consideration**: This aspect is crucial because it forms the foundation of our understanding.\n\n2. **Second point**: Building on the first point, we need to examine how these elements interact.\n\n3. **Final thoughts**: Taking everything into account, the best approach would be to implement a solution that balances all these factors.\n\nWould you like me to elaborate on any of these points?",
        
        "That's a fascinating question! Let me break this down into several key areas:\n\n## Overview\nThis topic involves multiple interconnected concepts that work together to create a comprehensive solution.\n\n## Key Components\n- **Component A**: Handles the primary functionality\n- **Component B**: Manages the secondary processes\n- **Component C**: Ensures everything works smoothly together\n\n## Implementation Strategy\n```javascript\n// Example implementation\nfunction handleProcess(input) {\n  const result = processInput(input);\n  return optimizeResult(result);\n}\n```\n\nThis approach ensures both efficiency and maintainability. What specific aspect would you like to explore further?",
        
        "Great question! This is actually a topic I find quite engaging. Let me share some insights based on current best practices:\n\n> \"The key to success in this area is understanding the underlying principles and applying them consistently.\"\n\n### Practical Applications\n1. **Immediate benefits**: You'll see improvements right away\n2. **Long-term advantages**: The real value becomes apparent over time\n3. **Scalability**: This approach grows with your needs\n\n### Common Pitfalls to Avoid\n- Don't rush the initial setup\n- Avoid over-complicating the solution\n- Remember to test thoroughly\n\nI hope this helps clarify things! Feel free to ask if you need more specific guidance.",
        
        "I'd be happy to help you with that! This is definitely an area where having the right approach makes all the difference.\n\n**Here's what I recommend:**\n\nStart with understanding the fundamentals, then gradually build up your knowledge. The learning curve might seem steep at first, but with consistent practice, you'll find it becomes much more intuitive.\n\n**Some practical tips:**\n- Begin with small, manageable projects\n- Don't be afraid to experiment and make mistakes\n- Seek feedback from others when possible\n- Document your learning process\n\nThe most important thing is to stay curious and keep practicing. Each challenge you overcome will make you stronger and more confident in tackling the next one.\n\nWhat specific area would you like to focus on first?"
      ];
      
      const randomResponse = responses[Math.floor(Math.random() * responses.length)];
      onSendMessage(randomResponse);
      setIsGenerating(false);
    }, 1500 + Math.random() * 2000);
  };

  const handleRegenerateResponse = () => {
    if (!session || session.messages.length === 0) return;
    
    const lastMessage = session.messages[session.messages.length - 1];
    if (lastMessage.role === 'assistant') {
      setIsGenerating(true);
      
      setTimeout(() => {
        const newResponses = [
          "Let me provide you with an alternative perspective on this topic. Here's another way to approach this challenge that might be more suitable for your specific situation.\n\n**Alternative Approach:**\n\nInstead of the traditional method, consider this innovative solution that has been gaining traction recently. It offers several advantages:\n\n- More efficient resource utilization\n- Better scalability options\n- Improved user experience\n- Easier maintenance and updates\n\nThis approach has been successfully implemented in various scenarios and has shown consistently positive results.",
          
          "I can offer a different angle on your question. Let me rephrase my response with additional context and perhaps a more detailed explanation of the concepts involved.\n\n## Detailed Analysis\n\nWhen we examine this from a different perspective, several interesting patterns emerge:\n\n### Pattern 1: Structural Considerations\nThe underlying structure plays a crucial role in determining the overall effectiveness of the solution.\n\n### Pattern 2: Performance Implications\nEach decision we make has cascading effects on system performance and user satisfaction.\n\n### Pattern 3: Future-Proofing\nIt's essential to consider how our choices today will impact future development and maintenance.\n\nBy taking these factors into account, we can develop a more robust and sustainable solution.",
          
          "Here's a fresh take on your question, with some additional insights that might prove valuable for your specific needs.\n\n**Key Insights:**\n\n1. **Context Matters**: The same solution might work differently in different environments\n2. **User-Centric Design**: Always consider the end-user experience\n3. **Iterative Improvement**: Start simple and refine based on feedback\n\n**Practical Implementation:**\n\n```python\n# Refined approach\ndef enhanced_solution(parameters):\n    # Validate inputs\n    if not validate_parameters(parameters):\n        return handle_error()\n    \n    # Process with improved algorithm\n    result = advanced_processing(parameters)\n    \n    # Return optimized output\n    return optimize_output(result)\n```\n\nThis refined approach addresses some of the limitations of conventional methods while maintaining simplicity and effectiveness."
        ];
        
        const newResponse = newResponses[Math.floor(Math.random() * newResponses.length)];
        onUpdateMessage(lastMessage.id, { content: newResponse });
        setIsGenerating(false);
        toast.success('Response regenerated!', {
          position: "top-center",
          autoClose: 2000,
          hideProgressBar: true,
        });
      }, 2000);
    }
  };

  const handleShare = (message: Message) => {
    setShareModal({ isOpen: true, message });
  };

  if (!session) {
    return (
      <div className="flex-1 flex flex-col h-screen bg-white dark:bg-slate-900">
        {/* Header */}
        <div className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl border-b border-slate-200/50 dark:border-slate-800/50 p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                onClick={onToggleSidebar}
                className="lg:hidden p-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 transition-all duration-200 hover:scale-105"
              >
                <Menu size={20} />
              </button>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-emerald-500 to-emerald-600 flex items-center justify-center shadow-lg shadow-emerald-500/30">
                  <Sparkles size={16} className="text-white" />
                </div>
                <h1 className="text-xl font-semibold bg-gradient-to-r from-slate-800 to-slate-600 dark:from-slate-200 dark:to-slate-400 bg-clip-text text-transparent">
                  ChatGPT
                </h1>
              </div>
            </div>
            <ThemeToggle />
          </div>
        </div>

        {/* Empty State */}
        <div className="flex-1 flex items-center justify-center p-8">
          <div className="text-center max-w-md">
            <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-br from-emerald-500 to-emerald-600 flex items-center justify-center shadow-2xl shadow-emerald-500/25">
              <Sparkles size={32} className="text-white" />
            </div>
            <h2 className="text-3xl font-bold mb-4 bg-gradient-to-r from-slate-800 to-slate-600 dark:from-slate-200 dark:to-slate-400 bg-clip-text text-transparent">
              How can I help you today?
            </h2>
            <p className="text-slate-600 dark:text-slate-400 text-lg leading-relaxed">
              Start a conversation and I'll do my best to assist you
            </p>
          </div>
        </div>

        {/* Chat Input */}
        <ChatInput 
          onSendMessage={handleSendMessage} 
          disabled={isGenerating}
        />
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col h-screen bg-white dark:bg-slate-900 relative">
      {/* Header */}
      <div className="bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl border-b border-slate-200/50 dark:border-slate-800/50 p-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={onToggleSidebar}
              className="lg:hidden p-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 transition-all duration-200 hover:scale-105"
            >
              <Menu size={20} />
            </button>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-emerald-500 to-emerald-600 flex items-center justify-center shadow-lg shadow-emerald-500/30">
                <Sparkles size={16} className="text-white" />
              </div>
              <h1 className="text-xl font-semibold text-slate-800 dark:text-slate-200 truncate">{session.title}</h1>
            </div>
          </div>
          <ThemeToggle />
        </div>
      </div>

      {/* Messages - Fixed height with scroll */}
      <div 
        ref={messagesContainerRef}
        onScroll={handleScroll}
        className="flex-1 overflow-y-auto custom-scrollbar"
      >
        {session.messages.length === 0 ? (
          <div className="flex items-center justify-center h-full min-h-[400px]">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-emerald-500/20 to-emerald-600/20 flex items-center justify-center">
                <Sparkles size={24} className="text-emerald-600 dark:text-emerald-400" />
              </div>
              <p className="text-slate-600 dark:text-slate-400 text-lg">
                Send a message to start the conversation
              </p>
            </div>
          </div>
        ) : (
          <>
            {session.messages.map((message) => (
              <MessageBubble
                key={message.id}
                message={message}
                onUpdate={(updates) => onUpdateMessage(message.id, updates)}
                onShare={handleShare}
              />
            ))}
            
            {isGenerating && (
              <div className="py-6 px-4 bg-slate-50/50 dark:bg-slate-800/30 border-b border-slate-100/50 dark:border-slate-800/30">
                <div className="max-w-4xl mx-auto">
                  <div className="flex gap-4 items-start">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gradient-to-br from-emerald-500 to-emerald-600 flex items-center justify-center shadow-lg shadow-emerald-500/30">
                      <RefreshCw size={16} className="text-white animate-spin" />
                    </div>
                    <div className="flex-1">
                      <div className="mb-2">
                        <span className="text-sm font-semibold tracking-wide text-slate-700 dark:text-slate-300">
                          ChatGPT
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400">
                        <div className="flex gap-1">
                          <div className="w-2 h-2 bg-slate-400 dark:bg-slate-500 rounded-full animate-bounce"></div>
                          <div className="w-2 h-2 bg-slate-400 dark:bg-slate-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                          <div className="w-2 h-2 bg-slate-400 dark:bg-slate-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                        </div>
                        <span className="text-sm">Thinking...</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </>
        )}
      </div>

      {/* Regenerate Button */}
      {session.messages.length > 0 && 
       session.messages[session.messages.length - 1]?.role === 'assistant' && (
        <div className="px-4 pb-4 bg-white dark:bg-slate-900">
          <div className="max-w-4xl mx-auto pl-12">
            <button
              onClick={handleRegenerateResponse}
              disabled={isGenerating}
              className="
                flex items-center gap-3 px-4 py-2 rounded-lg
                bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 
                border border-slate-300/50 dark:border-slate-600/50
                text-slate-700 dark:text-slate-300 hover:text-slate-800 dark:hover:text-slate-200 text-sm font-medium
                disabled:opacity-50 disabled:cursor-not-allowed
                transition-all duration-200 ease-out
                hover:scale-105 active:scale-95 disabled:hover:scale-100
                shadow-sm hover:shadow-md
              "
            >
              <RefreshCw size={16} className={isGenerating ? 'animate-spin' : ''} />
              Regenerate response
            </button>
          </div>
        </div>
      )}

      {/* Scroll to Bottom Button */}
      {showScrollButton && (
        <div className="absolute bottom-32 right-8">
          <button
            onClick={scrollToBottom}
            className="
              p-4 rounded-full shadow-xl
              bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 
              border border-slate-300/50 dark:border-slate-600/50
              text-slate-600 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200
              transition-all duration-300 ease-out
              hover:scale-110 hover:shadow-2xl
            "
            title="Scroll to bottom"
          >
            <ArrowDown size={20} />
          </button>
        </div>
      )}

      {/* Chat Input - Fixed at bottom */}
      <ChatInput 
        onSendMessage={handleSendMessage} 
        disabled={isGenerating}
      />

      {/* Share Modal */}
      <ShareModal 
        shareModal={shareModal}
        onClose={() => setShareModal({ isOpen: false })}
      />
    </div>
  );
}