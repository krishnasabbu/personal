import React from 'react';
import { useState } from 'react';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useChat } from './hooks/useChat';
import { ThemeProvider } from './contexts/ThemeContext';
import { Sidebar } from './components/Sidebar';
import { ChatArea } from './components/ChatArea';

function App() {
  const {
    sessions,
    currentSession,
    createNewSession,
    addMessage,
    updateMessage,
    deleteSession,
    clearAllSessions,
    selectSession
  } = useChat();

  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleNewChat = () => {
    createNewSession();
    setSidebarOpen(false);
  };

  const handleSelectSession = (sessionId: string) => {
    selectSession(sessionId);
    setSidebarOpen(false);
  };

  const handleSendMessage = (content: string) => {
    if (!currentSession) {
      createNewSession();
    }
    addMessage(content, 'user');
  };

  const handleUpdateMessage = (messageId: string, updates: any) => {
    updateMessage(messageId, updates);
  };

  const handleClearAll = () => {
    if (window.confirm('Delete all conversations? This cannot be undone.')) {
      clearAllSessions();
      setSidebarOpen(false);
    }
  };

  return (
    <ThemeProvider>
      <div className="h-screen flex overflow-hidden bg-white dark:bg-slate-900">
        <Sidebar
          sessions={sessions}
          currentSessionId={currentSession?.id || null}
          onNewChat={handleNewChat}
          onSelectSession={handleSelectSession}
          onClearAll={handleClearAll}
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
        />
        
        <ChatArea
          session={currentSession}
          onSendMessage={handleSendMessage}
          onUpdateMessage={handleUpdateMessage}
          onToggleSidebar={() => setSidebarOpen(true)}
        />

        <ToastContainer
          position="top-center"
          autoClose={2000}
          hideProgressBar={false}
          newestOnTop
          closeOnClick
          rtl={false}
          pauseOnFocusLoss
          draggable
          pauseOnHover
          theme="light"
        />
      </div>
    </ThemeProvider>
  );
}

export default App;