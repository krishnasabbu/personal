import { useState, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { ChatSession, Message } from '../types/chat';
import { useLocalStorage } from './useLocalStorage';

export function useChat() {
  const [sessions, setSessions] = useLocalStorage<ChatSession[]>('chat-sessions', []);
  const [currentSessionId, setCurrentSessionId] = useLocalStorage<string | null>('current-session-id', null);

  const currentSession = sessions.find(s => s.id === currentSessionId) || null;

  const createNewSession = useCallback(() => {
    const newSession: ChatSession = {
      id: uuidv4(),
      title: 'New Chat',
      messages: [],
      createdAt: new Date(),
      updatedAt: new Date()
    };

    setSessions(prev => [newSession, ...prev]);
    setCurrentSessionId(newSession.id);
    return newSession;
  }, [setSessions, setCurrentSessionId]);

  const addMessage = useCallback((content: string, role: 'user' | 'assistant') => {
    const message: Message = {
      id: uuidv4(),
      content,
      role,
      timestamp: new Date()
    };

    setSessions(prev => prev.map(session => {
      if (session.id === currentSessionId) {
        const updatedMessages = [...session.messages, message];
        const title = session.title === 'New Chat' && updatedMessages.length === 1 
          ? content.slice(0, 30) + (content.length > 30 ? '...' : '')
          : session.title;

        return {
          ...session,
          messages: updatedMessages,
          title,
          updatedAt: new Date()
        };
      }
      return session;
    }));

    return message;
  }, [setSessions, currentSessionId]);

  const updateMessage = useCallback((messageId: string, updates: Partial<Message>) => {
    setSessions(prev => prev.map(session => {
      if (session.id === currentSessionId) {
        return {
          ...session,
          messages: session.messages.map(msg => 
            msg.id === messageId ? { ...msg, ...updates } : msg
          ),
          updatedAt: new Date()
        };
      }
      return session;
    }));
  }, [setSessions, currentSessionId]);

  const deleteSession = useCallback((sessionId: string) => {
    setSessions(prev => prev.filter(s => s.id !== sessionId));
    if (currentSessionId === sessionId) {
      setCurrentSessionId(null);
    }
  }, [setSessions, setCurrentSessionId, currentSessionId]);

  const clearAllSessions = useCallback(() => {
    setSessions([]);
    setCurrentSessionId(null);
  }, [setSessions, setCurrentSessionId]);

  const selectSession = useCallback((sessionId: string) => {
    setCurrentSessionId(sessionId);
  }, [setCurrentSessionId]);

  return {
    sessions,
    currentSession,
    createNewSession,
    addMessage,
    updateMessage,
    deleteSession,
    clearAllSessions,
    selectSession
  };
}