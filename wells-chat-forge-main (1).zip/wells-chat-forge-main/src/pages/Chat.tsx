import { useState, useEffect, useRef } from 'react';
import { ChatSidebar } from '@/components/Chat/ChatSidebar';
import { ChatMessage } from '@/components/Chat/ChatMessage';
import { ChatInput } from '@/components/Chat/ChatInput';
import { LoadingIndicator } from '@/components/Chat/LoadingIndicator';
import { ScrollToBottom } from '@/components/Chat/ScrollToBottom';
import { ThemeToggle } from '@/components/Chat/ThemeToggle';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useChat } from '@/hooks/useChat';
import { useTheme } from '@/hooks/useTheme';
import { cn } from '@/lib/utils';

export default function Chat() {
  const {
    sessions,
    currentSession,
    currentSessionId,
    isLoading,
    createNewSession,
    selectSession,
    sendMessage,
    editMessage,
    clearAllSessions,
  } = useChat();

  const { theme } = useTheme();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(window.innerWidth < 768);
  const [showScrollToBottom, setShowScrollToBottom] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [currentSession?.messages, isLoading]);

  // Handle scroll detection for scroll-to-bottom button
  const handleScroll = () => {
    if (scrollAreaRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = scrollAreaRef.current;
      const isNearBottom = scrollHeight - scrollTop - clientHeight < 100;
      setShowScrollToBottom(!isNearBottom && scrollHeight > clientHeight);
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleEditMessage = (messageId: string, newContent: string) => {
    editMessage(messageId, newContent);
  };

  return (
    <div className="flex h-screen bg-chat-background">
      {/* Sidebar */}
      <ChatSidebar
        sessions={sessions}
        currentSessionId={currentSessionId}
        onNewChat={createNewSession}
        onSelectSession={selectSession}
        onClearAll={clearAllSessions}
        isCollapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
      />

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col min-w-0 h-screen">
        {/* Header */}
        <div className="border-b border-border bg-card p-4 flex-shrink-0">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-semibold text-foreground">
                {currentSession?.title || (theme === 'wells-fargo' ? 'Wells Fargo Chat Assistant' : 'Chat Assistant')}
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                How can I help you today?
              </p>
            </div>
            <ThemeToggle />
          </div>
        </div>

        {/* Messages Area - Scrollable */}
        <div className="flex-1 overflow-y-auto relative">
          <div className="p-4 space-y-4 max-w-4xl mx-auto">
            {!currentSession || currentSession.messages.length === 0 ? (
              <div className="flex items-center justify-center h-full min-h-[400px]">
                <div className="text-center space-y-4">
                  <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center">
                    <svg className="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-semibold text-foreground font-serif">
                    Start a conversation
                  </h3>
                  <p className="text-muted-foreground max-w-md">
                    Welcome to Wells Fargo Chat Assistant. I'm here to help you with your questions and provide support.
                  </p>
                </div>
              </div>
            ) : (
              <>
                {currentSession.messages.map((message) => (
                  <ChatMessage
                    key={message.id}
                    message={message}
                    onEdit={message.role === 'user' ? handleEditMessage : undefined}
                  />
                ))}
                {isLoading && <LoadingIndicator />}
              </>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Scroll to Bottom Button */}
          <ScrollToBottom 
            show={showScrollToBottom} 
            onClick={scrollToBottom}
          />
        </div>

        {/* Input Area - Fixed at bottom */}
        <div className="border-t border-border bg-card flex-shrink-0">
          <div className="max-w-4xl mx-auto">
            <ChatInput
              onSendMessage={sendMessage}
              isLoading={isLoading}
            />
          </div>
        </div>
      </div>
    </div>
  );
}