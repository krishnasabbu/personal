import Chat from './Chat';

const Index = () => {
  return <Chat />;
};

export default Index;
