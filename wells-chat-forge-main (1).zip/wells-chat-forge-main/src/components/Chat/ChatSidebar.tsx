import { useState } from 'react';
import { Plus, ChevronLeft, ChevronRight, Trash2, MessageSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';

interface ChatSession {
  id: string;
  title: string;
  timestamp: Date;
}

interface ChatSidebarProps {
  sessions: ChatSession[];
  currentSessionId: string | null;
  onNewChat: () => void;
  onSelectSession: (sessionId: string) => void;
  onClearAll: () => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
}

export function ChatSidebar({
  sessions,
  currentSessionId,
  onNewChat,
  onSelectSession,
  onClearAll,
  isCollapsed,
  onToggleCollapse,
}: ChatSidebarProps) {
  return (
    <div className={cn(
      "h-full border-r border-sidebar-border bg-sidebar transition-all duration-300 flex flex-col",
      isCollapsed ? "w-0 min-w-0 md:w-12" : "w-full md:w-48"
    )}>
      {/* Header */}
      <div className="p-3 border-b border-sidebar-border">
        <div className="flex items-center justify-between">
          <h2 className={cn(
            "font-semibold text-sidebar-foreground transition-opacity text-sm",
            isCollapsed ? "hidden md:hidden" : "block"
          )}>
            Chat History
          </h2>
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggleCollapse}
            className="h-7 w-7 p-0 hover:bg-sidebar-accent text-sidebar-foreground"
          >
            {isCollapsed ? (
              <ChevronRight className="h-3 w-3" />
            ) : (
              <ChevronLeft className="h-3 w-3" />
            )}
          </Button>
        </div>
      </div>

      {/* New Chat Button */}
      <div className="p-3">
        <Button
          onClick={onNewChat}
          className={cn(
            "w-full bg-sidebar-primary text-sidebar-primary-foreground hover:bg-sidebar-primary/90 shadow-sm transition-all text-xs h-8",
            isCollapsed ? "hidden md:flex md:w-8 md:h-8 md:p-0 md:justify-center" : "flex"
          )}
        >
          <Plus className={cn("h-3 w-3", isCollapsed ? "" : "mr-2")} />
          <span className={cn(isCollapsed ? "hidden" : "block")}>New Chat</span>
        </Button>
      </div>

      {/* Chat Sessions */}
      <ScrollArea className="flex-1 px-2">
        <div className="space-y-1">
          {sessions.map((session) => (
            <Button
              key={session.id}
              variant={currentSessionId === session.id ? "secondary" : "ghost"}
              onClick={() => onSelectSession(session.id)}
              className={cn(
                "w-full justify-start text-left h-auto py-2 px-2 transition-all",
                isCollapsed ? "hidden md:flex md:w-8 md:h-8 md:p-0 md:justify-center" : "flex"
              )}
              title={isCollapsed ? session.title : undefined}
            >
              <div className="flex-1 min-w-0">
                <p className={cn(
                  "text-xs font-medium text-sidebar-foreground truncate",
                  isCollapsed ? "hidden" : "block"
                )}>
                  {session.title}
                </p>
                <p className={cn(
                  "text-xs text-sidebar-foreground/60",
                  isCollapsed ? "hidden" : "block"
                )}>
                  {session.timestamp.toLocaleDateString()}
                </p>
              </div>
              {isCollapsed && (
                <MessageSquare className="h-3 w-3 text-sidebar-foreground" />
              )}
            </Button>
          ))}
          {sessions.length === 0 && !isCollapsed && (
            <div className="text-center py-6 text-sidebar-foreground/60">
              <p className="text-xs">No chat sessions yet</p>
              <p className="text-xs mt-1">Start a new conversation!</p>
            </div>
          )}
        </div>
      </ScrollArea>

      {/* Clear All Button */}
      {sessions.length > 0 && (
        <>
          <Separator className="bg-sidebar-border" />
          <div className="p-3">
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button
                  variant="destructive"
                  className={cn(
                    "w-full text-xs h-8",
                    isCollapsed ? "hidden md:flex md:w-8 md:h-8 md:p-0 md:justify-center" : "flex"
                  )}
                >
                  <Trash2 className={cn("h-3 w-3", isCollapsed ? "" : "mr-2")} />
                  <span className={cn(isCollapsed ? "hidden" : "block")}>Clear All</span>
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Clear All Conversations</AlertDialogTitle>
                  <AlertDialogDescription>
                    This action cannot be undone. This will permanently delete all your chat sessions and messages.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={onClearAll}>
                    Clear All
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </>
      )}
    </div>
  );
}