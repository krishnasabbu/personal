import { ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface ScrollToBottomProps {
  show: boolean;
  onClick: () => void;
}

export function ScrollToBottom({ show, onClick }: ScrollToBottomProps) {
  return (
    <div className={cn(
      "fixed bottom-32 right-8 transition-all duration-300 z-10",
      show ? "opacity-100 translate-y-0" : "opacity-0 translate-y-2 pointer-events-none"
    )}>
      <Button
        onClick={onClick}
        size="icon"
        className="rounded-full shadow-lg bg-primary text-primary-foreground hover:bg-primary/90"
      >
        <ChevronDown className="h-4 w-4" />
      </Button>
    </div>
  );
}