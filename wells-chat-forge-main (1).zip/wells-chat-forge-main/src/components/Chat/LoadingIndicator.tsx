import { Card, CardContent } from '@/components/ui/card';

export function LoadingIndicator() {
  return (
    <div className="flex justify-start w-full mb-4">
      <Card className="max-w-[80%] bg-assistant-message border-secondary/20 shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-center space-x-2">
            <span className="text-sm text-muted-foreground">Assistant is typing</span>
            <div className="flex space-x-1">
              <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
              <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
              <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}