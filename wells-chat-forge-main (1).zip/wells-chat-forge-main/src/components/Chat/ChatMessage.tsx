import { useState } from 'react';
import { Copy, Edit3, Check, ThumbsUp, ThumbsDown, Share, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import ReactMarkdown from 'react-markdown';
import { useToast } from '@/hooks/use-toast';

interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
}

interface ChatMessageProps {
  message: Message;
  onEdit?: (messageId: string, newContent: string) => void;
  isEditing?: boolean;
}

export function ChatMessage({ message, onEdit, isEditing }: ChatMessageProps) {
  const [copied, setCopied] = useState(false);
  const [liked, setLiked] = useState(false);
  const [disliked, setDisliked] = useState(false);
  const [showControls, setShowControls] = useState(false);
  const { toast } = useToast();

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message.content);
      setCopied(true);
      toast({
        description: "Message copied to clipboard",
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      toast({
        description: "Failed to copy message",
        variant: "destructive",
      });
    }
  };

  const handleEdit = () => {
    if (onEdit) {
      const newContent = prompt("Edit your message:", message.content);
      if (newContent && newContent !== message.content) {
        onEdit(message.id, newContent);
      }
    }
  };

  const handleLike = () => {
    setLiked(!liked);
    setDisliked(false);
    toast({
      description: liked ? "Like removed" : "Message liked",
    });
  };

  const handleDislike = () => {
    setDisliked(!disliked);
    setLiked(false);
    toast({
      description: disliked ? "Dislike removed" : "Message disliked",
    });
  };

  const handleShare = () => {
    toast({
      description: "Share functionality would be implemented here",
    });
  };

  const handleDownload = () => {
    toast({
      description: "Download functionality would be implemented here",
    });
  };

  const isUser = message.role === 'user';

  return (
    <div 
      className="flex w-full mb-4"
      onMouseEnter={() => setShowControls(true)}
      onMouseLeave={() => setShowControls(false)}
    >
      <div className="w-full p-4 hover:bg-message-background transition-colors duration-200">
        <div>
          <div className="flex items-start justify-between gap-2 mb-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-medium text-muted-foreground">
                {isUser ? 'You' : 'Assistant'}
              </span>
              <span className="text-xs text-muted-foreground">
                {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
            
            {/* Message Controls */}
            <div className={cn(
              "flex items-center gap-1 transition-opacity",
              showControls ? "opacity-100" : "opacity-0"
            )}>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleCopy}
                className="h-6 w-6 p-0 hover:bg-accent/50"
                title="Copy"
              >
                {copied ? (
                  <Check className="h-3 w-3 text-green-600" />
                ) : (
                  <Copy className="h-3 w-3" />
                )}
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={handleLike}
                className={cn(
                  "h-6 w-6 p-0 hover:bg-accent/50",
                  liked ? "text-green-600" : ""
                )}
                title="Like"
              >
                <ThumbsUp className="h-3 w-3" />
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={handleDislike}
                className={cn(
                  "h-6 w-6 p-0 hover:bg-accent/50",
                  disliked ? "text-red-600" : ""
                )}
                title="Dislike"
              >
                <ThumbsDown className="h-3 w-3" />
              </Button>
              
              {isUser && onEdit && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleEdit}
                  className="h-6 w-6 p-0 hover:bg-accent/50"
                  title="Edit"
                >
                  <Edit3 className="h-3 w-3" />
                </Button>
              )}
              
              <Button
                variant="ghost"
                size="sm"
                onClick={handleShare}
                className="h-6 w-6 p-0 hover:bg-accent/50"
                title="Share"
              >
                <Share className="h-3 w-3" />
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={handleDownload}
                className="h-6 w-6 p-0 hover:bg-accent/50"
                title="Download"
              >
                <Download className="h-3 w-3" />
              </Button>
            </div>
          </div>
          
          <div className="text-sm leading-relaxed text-foreground">
            {isUser ? (
              <p className="whitespace-pre-wrap">{message.content}</p>
            ) : (
              <div className="prose prose-sm max-w-none dark:prose-invert">
                <ReactMarkdown 
                  components={{
                    p: ({ children }) => <p className="mb-2 last:mb-0">{children}</p>,
                    code: ({ children }) => (
                      <code className="bg-muted px-1 py-0.5 rounded text-xs font-mono">
                        {children}
                      </code>
                    ),
                    pre: ({ children }) => (
                      <pre className="bg-muted p-3 rounded-md overflow-x-auto">
                        {children}
                      </pre>
                    ),
                  }}
                >
                  {message.content}
                </ReactMarkdown>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}