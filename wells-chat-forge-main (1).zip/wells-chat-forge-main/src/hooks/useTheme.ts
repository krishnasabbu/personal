import { useState, useEffect } from 'react';

type Theme = 'wells-fargo' | 'chatgpt';

export function useTheme() {
  const [theme, setTheme] = useState<Theme>(() => {
    const saved = localStorage.getItem('chat-theme');
    return (saved as Theme) || 'wells-fargo';
  });

  useEffect(() => {
    const root = document.documentElement;
    
    if (theme === 'chatgpt') {
      root.classList.add('chatgpt-theme');
      root.classList.remove('wells-fargo-theme');
    } else {
      root.classList.add('wells-fargo-theme');
      root.classList.remove('chatgpt-theme');
    }
    
    localStorage.setItem('chat-theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => prev === 'wells-fargo' ? 'chatgpt' : 'wells-fargo');
  };

  return { theme, setTheme, toggleTheme };
}