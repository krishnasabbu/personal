import { useState, useEffect, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';

interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
}

interface ChatSession {
  id: string;
  title: string;
  timestamp: Date;
  messages: Message[];
}

const STORAGE_KEY = 'wells-chat-sessions';

export function useChat() {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Load sessions from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsedSessions = JSON.parse(stored).map((session: any) => ({
          ...session,
          timestamp: new Date(session.timestamp),
          messages: session.messages.map((msg: any) => ({
            ...msg,
            timestamp: new Date(msg.timestamp),
          })),
        }));
        setSessions(parsedSessions);
        
        // Set most recent session as current if exists
        if (parsedSessions.length > 0) {
          setCurrentSessionId(parsedSessions[0].id);
        }
      }
    } catch (error) {
      console.error('Failed to load chat sessions:', error);
    }
  }, []);

  // Save sessions to localStorage whenever sessions change
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions));
    } catch (error) {
      console.error('Failed to save chat sessions:', error);
    }
  }, [sessions]);

  const currentSession = sessions.find(s => s.id === currentSessionId);

  const createNewSession = useCallback(() => {
    const newSession: ChatSession = {
      id: uuidv4(),
      title: 'New Chat',
      timestamp: new Date(),
      messages: [],
    };

    setSessions(prev => [newSession, ...prev]);
    setCurrentSessionId(newSession.id);
    return newSession.id;
  }, []);

  const selectSession = useCallback((sessionId: string) => {
    setCurrentSessionId(sessionId);
  }, []);

  const addMessage = useCallback((content: string, role: 'user' | 'assistant') => {
    const message: Message = {
      id: uuidv4(),
      content,
      role,
      timestamp: new Date(),
    };

    setSessions(prev => prev.map(session => {
      if (session.id === currentSessionId) {
        const updatedMessages = [...session.messages, message];
        
        // Update session title based on first user message
        let updatedTitle = session.title;
        if (role === 'user' && session.messages.length === 0) {
          updatedTitle = content.slice(0, 50) + (content.length > 50 ? '...' : '');
        }

        return {
          ...session,
          title: updatedTitle,
          messages: updatedMessages,
          timestamp: new Date(),
        };
      }
      return session;
    }));

    return message.id;
  }, [currentSessionId]);

  const editMessage = useCallback((messageId: string, newContent: string) => {
    setSessions(prev => prev.map(session => {
      if (session.id === currentSessionId) {
        const messageIndex = session.messages.findIndex(m => m.id === messageId);
        if (messageIndex === -1) return session;

        // Remove all messages after the edited message (including assistant responses)
        const updatedMessages = session.messages.slice(0, messageIndex + 1);
        updatedMessages[messageIndex] = {
          ...updatedMessages[messageIndex],
          content: newContent,
          timestamp: new Date(),
        };

        return {
          ...session,
          messages: updatedMessages,
          timestamp: new Date(),
        };
      }
      return session;
    }));
  }, [currentSessionId]);

  const sendMessage = useCallback(async (content: string) => {
    if (!currentSessionId) {
      const newSessionId = createNewSession();
      setCurrentSessionId(newSessionId);
    }

    // Add user message
    addMessage(content, 'user');
    setIsLoading(true);

    // Simulate AI response (replace with actual API call)
    setTimeout(() => {
      const responses = [
        "I understand your question. Let me help you with that.",
        "That's an interesting point. Here's what I think:\n\n**Key considerations:**\n- First point to consider\n- Second important aspect\n- Third relevant factor\n\nWould you like me to elaborate on any of these points?",
        "I can help you with that! Here are some options to consider:\n\n1. **Option A**: This approach focuses on...\n2. **Option B**: Alternatively, you could...\n3. **Option C**: A third possibility is...\n\nWhat sounds most relevant to your situation?",
        "Thank you for that question. Based on Wells Fargo's approach to customer service, I'd recommend the following steps:\n\n```\n1. Review your current situation\n2. Identify available options\n3. Make an informed decision\n```\n\nIs there anything specific you'd like me to clarify?",
      ];
      const randomResponse = responses[Math.floor(Math.random() * responses.length)];
      addMessage(randomResponse, 'assistant');
      setIsLoading(false);
    }, 1500 + Math.random() * 2000); // Random delay between 1.5-3.5 seconds
  }, [currentSessionId, createNewSession, addMessage]);


  const clearAllSessions = useCallback(() => {
    setSessions([]);
    setCurrentSessionId(null);
  }, []);

  return {
    sessions,
    currentSession,
    currentSessionId,
    isLoading,
    createNewSession,
    selectSession,
    sendMessage,
    editMessage,
    clearAllSessions,
  };
}